package com.example.SplitwiseLike.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
@Entity
public class Transaction {

	@Id
	private long transacton_id;
	private long group_id;
	private String from_user_id;
	private String to_user_id;
	private double transaction_amount;
	public long getTransacton_id() {
		return transacton_id;
	}
	public void setTransacton_id(long transacton_id) {
		this.transacton_id = transacton_id;
	}
	public long getGroup_id() {
		return group_id;
	}
	public void setGroup_id(long group_id) {
		this.group_id = group_id;
	}
	public String getFrom_user_id() {
		return from_user_id;
	}
	public void setFrom_user_id(String from_user_id) {
		this.from_user_id = from_user_id;
	}
	public String getTo_user_id() {
		return to_user_id;
	}
	public void setTo_user_id(String to_user_id) {
		this.to_user_id = to_user_id;
	}
	public double getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(double transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	
	
}
