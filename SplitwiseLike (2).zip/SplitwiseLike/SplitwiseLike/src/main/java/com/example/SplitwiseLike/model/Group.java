package com.example.SplitwiseLike.model;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
@Entity
public class Group {

	@Id
	private long group_id;
	private String group_name;
	private long num_members;
	private long num_transactions;
	
    @ManyToMany(mappedBy = "Users", cascade = { CascadeType.ALL })
    private Set<User> users_set = new HashSet<User>();
	
	public long getGroup_id() {
		return group_id;
	}
	public void setGroup_id(long group_id) {
		this.group_id = group_id;
	}
	public String getGroup_name() {
		return group_name;
	}
	public void setGroup_name(String group_name) {
		this.group_name = group_name;
	}
	public long getNum_members() {
		return num_members;
	}
	public void setNum_members(long num_members) {
		this.num_members = num_members;
	}
	public long getNum_transactions() {
		return num_transactions;
	}
	public void setNum_transactions(long num_transactions) {
		this.num_transactions = num_transactions;
	}
	
	
	
}
