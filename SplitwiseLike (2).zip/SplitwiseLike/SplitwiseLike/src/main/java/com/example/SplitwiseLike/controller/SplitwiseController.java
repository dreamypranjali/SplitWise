package com.example.SplitwiseLike.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.SplitwiseLike.model.User;
import com.example.SplitwiseLike.repository.UserRepository;

@RestController
public class SplitwiseController {
	
    @Autowired
	private UserRepository userRepository;
    
    @GetMapping("/user/{user_name}")
    public ResponseEntity getProductById(@PathVariable String user_name) {

        String user = this.userRepository.findUserByName(user_name);

        if(user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.ok("The user with name: " + user_name + " was not found.");
        }
    }
	
}
