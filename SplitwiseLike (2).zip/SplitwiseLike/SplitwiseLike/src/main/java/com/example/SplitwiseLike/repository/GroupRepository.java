package com.example.SplitwiseLike.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.SplitwiseLike.model.Group;

 
 public interface GroupRepository extends JpaRepository<Group, Integer> {

		//Create a custom method that will run the query. The query will use the name passed as the parameter.This query will make use of JPQL.
		

		//https://stackoverflow.com/questions/50452929/spring-data-jpa-many-to-many-query
		//https://codejava.net/frameworks/spring/jpa-join-query-for-like-search-examples
	 
	 	//@Query
	 	
		
	}
