package com.example.SplitwiseLike.Service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.SplitwiseLike.repository.UserRepository;
public class UserService {
	
	@Autowired
	UserRepository ur;
	public String fetchUserByName(String name){
		return ur.findUserByName(name);
	}
	
	//public String fetchUserGroups(){}
}
