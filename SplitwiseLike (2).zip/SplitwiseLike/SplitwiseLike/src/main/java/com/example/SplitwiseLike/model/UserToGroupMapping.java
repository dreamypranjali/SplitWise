package com.example.SplitwiseLike.model;

public class UserToGroupMapping {

}
