package com.example.SplitwiseLike.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.SplitwiseLike.model.User;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Integer> {

	//Create a custom method that will run the query. The query will use the name passed as the parameter.This query will make use of JPQL.
	
	//https://springframework.guru/spring-data-jpa-query/
	
	@Query("SELECT user_name FROM User u WHERE u.user_name = :name")
	public String findUserByName(@Param("name") String name);

	//https://stackoverflow.com/questions/50452929/spring-data-jpa-many-to-many-query
	//https://codejava.net/frameworks/spring/jpa-join-query-for-like-search-examples
	
	
	
}