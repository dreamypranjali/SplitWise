package com.example.SplitwiseLike.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinTable;
import jakarta.persistence.JoinColumn;
import java.util.*;

@Entity
public class User {
	
	@Id
	private long user_id;
	private String user_name;
	private String phone_no;
	private double lent;
	private double borrowed;
	private String password;
	
	//getter setter methods for each field in the user class
    @ManyToMany(cascade = {
            CascadeType.ALL
        })
    
    @JoinTable(
            name = "user_groups",
            joinColumns = {
                @JoinColumn(name = "user_id")
            },
            inverseJoinColumns = {
                @JoinColumn(name = "group_id")
            }
        )
    Set < Group > projects = new HashSet < Group > ();
        

	public long getUser_id() {
		return user_id;
	}
	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public double getLent() {
		return lent;
	}
	public void setLent(double lent) {
		this.lent = lent;
	}
	public double getBorrowed() {
		return borrowed;
	}
	public void setBorrowed(double borrowed) {
		this.borrowed = borrowed;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String phone_no) {
		this.password = password;
	}
	
	
	
	
	
}
