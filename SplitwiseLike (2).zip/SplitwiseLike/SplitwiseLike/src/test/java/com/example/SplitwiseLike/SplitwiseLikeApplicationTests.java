package com.example.SplitwiseLike;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SplitwiseLikeApplicationTests {

	@Test
	void contextLoads() {
	}

}
